const CONFIG = {
  PORT: 3000,
  DB_URL: "mongodb://localhost:27017/second-hand-electronics",
  SECRET: "10b09ba8-c53c-4213-bba7-992a4bb26e6e",
};

module.exports = CONFIG;
