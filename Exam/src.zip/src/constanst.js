const constants = {
    PORT: 3000,
    DB_URL: "mongodb://127.0.0.1:27017/exam-21", 
    SECRET: "e1c22f91-8048-48d5-bda8-6df6897aa325",
  };
  
  module.exports = constants;