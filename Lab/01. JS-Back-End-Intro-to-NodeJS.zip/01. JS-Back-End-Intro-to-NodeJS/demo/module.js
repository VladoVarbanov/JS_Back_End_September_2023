console.log(this === global);
console.log(this);
// console.log(global);
// console.log(globalThis === global)