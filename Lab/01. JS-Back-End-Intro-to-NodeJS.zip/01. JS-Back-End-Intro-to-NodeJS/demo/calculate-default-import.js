const calc = require('./calculator-default-export');

console.log(calc.sum(2, 3));
console.log(calc.multiply(2, 3));
console.log(calc.subtract(2, 3));