let name = 'Pesho';
let age = 20;

let info = `I am ${name} and I am ${age} years old`;

console.log(info);
