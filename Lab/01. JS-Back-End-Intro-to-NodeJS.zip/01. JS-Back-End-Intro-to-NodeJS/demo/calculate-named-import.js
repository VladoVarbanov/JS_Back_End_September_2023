const { multiply, subtract, sum } = require('./calculator-named-export');

console.log(sum(2, 3));
console.log(multiply(2, 3));
console.log(subtract(2, 3));